"""Button platform for Hundesystem."""
# Placeholder file
